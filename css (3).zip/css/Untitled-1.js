<!DOCTYPE html>
<html lang="uk">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Динамічне меню</title>
  <style>
    body {
      font-family: sans-serif;
      margin: 0;
      padding: 0;
    }

    .main-menu {
      background: #333;
      color: white;
      position: relative;
    }

    .menu {
      list-style: none;
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: row;
      transition: all 0.3s ease;
    }

    .menu li {
      position: relative;
    }

    .menu a {
      display: block;
      padding: 1rem;
      color: white;
      text-decoration: none;
    }

    .menu a:hover,
    .menu a.active {
      background: #444;
    }

    .submenu {
      display: none;
      position: absolute;
      top: 100%;
      left: 0;
      background: #444;
      flex-direction: column;
      min-width: 150px;
      z-index: 1000;
    }

    .submenu.open {
      display: block;
      animation: fadeIn 0.3s ease;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-10px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .has-submenu::after {
      content: " ▼";
      font-size: 0.8em;
    }

    .burger-menu {
      display: none;
      background: none;
      border: none;
      color: white;
      font-size: 2rem;
      padding: 1rem;
    }

    @media (max-width: 768px) {
      .burger-menu {
        display: block;
      }

      .menu {
        display: none;
        flex-direction: column;
        width: 100%;
        background: #333;
      }

      .menu-open {
        display: flex;
      }

      .submenu {
        position: relative;
      }
    }
  </style>
</head>
<body>

<nav class="main-menu">
  <button class="burger-menu" aria-label="Меню" aria-expanded="false" aria-controls="menuContainer">
    ☰
  </button>
  <ul id="menuContainer" class="menu" role="menubar">
    <!-- Пункти меню будуть додані динамічно -->
  </ul>
</nav>

<script>
  const menuData = {
    "items": [
      {
        "title": "Головна",
        "link": "/",
        "submenu": []
      },
      {
        "title": "Про нас",
        "link": "#",
        "submenu": [
          {
            "title": "Команда",
            "link": "/team",
            "submenu": []
          },
          {
            "title": "Історія",
            "link": "/history",
            "submenu": [
              {
                "title": "2020",
                "link": "/history/2020",
                "submenu": []
              },
              {
                "title": "2021",
                "link": "/history/2021",
                "submenu": []
              }
            ]
          }
        ]
      },
      {
        "title": "Послуги",
        "link": "/services",
        "submenu": []
      },
      {
        "title": "Блог",
        "link": "/blog",
        "submenu": []
      },
      {
        "title": "Контакти",
        "link": "/contact",
        "submenu": []
      }
    ]
  };

  const menuContainer = document.getElementById("menuContainer");

  function createMenuItems(items, level = 1) {
    const ul = document.createElement("ul");
    ul.classList.add(`submenu`, `level-${level}`);
    ul.setAttribute("role", "menu");

    items.forEach(item => {
      const li = document.createElement("li");
      li.classList.add("menu-item");
      li.setAttribute("role", "none");

      const a = document.createElement("a");
      a.textContent = item.title;
      a.href = item.link || "#";
      a.classList.add("menu-link");
      a.setAttribute("role", "menuitem");
      a.tabIndex = 0;

      li.appendChild(a);

      if (item.submenu && item.submenu.length > 0) {
        a.classList.add("has-submenu");
        const subMenu = createMenuItems(item.submenu, level + 1);
        li.appendChild(subMenu);

        a.addEventListener("click", (e) => {
          e.preventDefault();
          subMenu.classList.toggle("open");
          a.classList.toggle("open");
        });
      }

      li.addEventListener("click", () => {
        document.querySelectorAll(".active").forEach(el => el.classList.remove("active"));
        a.classList.add("active");
      });

      ul.appendChild(li);
    });

    return ul;
  }

  function renderMenu() {
    const menu = createMenuItems(menuData.items);
    menuContainer.appendChild(menu);
  }

  renderMenu();

  // BURGER BUTTON
  const burger = document.querySelector('.burger-menu');
  burger.addEventListener('click', () => {
    menuContainer.classList.toggle('menu-open');
    burger.setAttribute("aria-expanded", menuContainer.classList.contains("menu-open"));
  });
</script>

</body>
</html>
