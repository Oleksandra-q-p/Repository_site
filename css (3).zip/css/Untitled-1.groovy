<!DOCTYPE html>
<html lang="uk">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Фільтрація та сортування</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      padding: 20px;
      background: #f2f2f2;
    }

    .filters {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-bottom: 20px;
    }

    .filters input, .filters select {
      padding: 8px;
      font-size: 16px;
    }

    #items-container {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
      gap: 15px;
    }

    .item {
      background: white;
      padding: 15px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .item h4 {
      margin: 0 0 10px;
    }

    .reset-btn {
      background: crimson;
      color: white;
      padding: 8px 14px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .active-filters {
      margin-top: 10px;
      font-size: 14px;
    }
  </style>
</head>
<body>

  <div class="filters">
    <input type="text" id="search" placeholder="Пошук...">
    <select id="categoryFilter">
      <option value="">Усі категорії</option>
      <option value="Електроніка">Електроніка</option>
      <option value="Одяг">Одяг</option>
      <option value="Книги">Книги</option>
    </select>
    <select id="sortBy">
      <option value="name">Сортувати: Назва</option>
      <option value="price-asc">Сортувати: Ціна ↑</option>
      <option value="price-desc">Сортувати: Ціна ↓</option>
    </select>
    <button class="reset-btn" id="resetBtn">Скинути</button>
  </div>

  <div class="active-filters" id="activeFilters"></div>

  <div id="items-container"></div>

  <script>
    const items = [
      { name: "Навушники", price: 1000, category: "Електроніка" },
      { name: "Футболка", price: 500, category: "Одяг" },
      { name: "Планшет", price: 3000, category: "Електроніка" },
      { name: "Книга 'JS для початківців'", price: 350, category: "Книги" },
      { name: "Куртка", price: 1500, category: "Одяг" },
      { name: "Роутер", price: 850, category: "Електроніка" }
    ];

    class FilterSystem {
      constructor(data) {
        this.data = data;
        this.filteredData = [...data];
        this.searchInput = document.getElementById('search');
        this.sortSelect = document.getElementById('sortBy');
        this.categoryFilter = document.getElementById('categoryFilter');
        this.container = document.getElementById('items-container');
        this.activeFilters = document.getElementById('activeFilters');
        this.resetBtn = document.getElementById('resetBtn');

        this.addEvents();
        this.applyFilters();
      }

      addEvents() {
        this.searchInput.addEventListener('input', () => this.applyFilters());
        this.sortSelect.addEventListener('change', () => this.applyFilters());
        this.categoryFilter.addEventListener('change', () => this.applyFilters());
        this.resetBtn.addEventListener('click', () => this.resetFilters());
      }

      resetFilters() {
        this.searchInput.value = '';
        this.sortSelect.value = 'name';
        this.categoryFilter.value = '';
        this.applyFilters();
      }

      applyFilters() {
        let result = [...this.data];

        const search = this.searchInput.value.toLowerCase();
        if (search) {
          result = result.filter(item => item.name.toLowerCase().includes(search));
        }

        const category = this.categoryFilter.value;
        if (category) {
          result = result.filter(item => item.category === category);
        }

        const sortValue = this.sortSelect.value;
        if (sortValue === 'name') {
          result.sort((a, b) => a.name.localeCompare(b.name));
        } else if (sortValue === 'price-asc') {
          result.sort((a, b) => a.price - b.price);
        } else if (sortValue === 'price-desc') {
          result.sort((a, b) => b.price - a.price);
        }

        this.filteredData = result;
        this.render();
      }

      render() {
        this.container.innerHTML = '';
        if (this.filteredData.length === 0) {
          this.container.innerHTML = '<p>Нічого не знайдено.</p>';
          return;
        }

        for (const item of this.filteredData) {
          const div = document.createElement('div');
          div.className = 'item';
          div.innerHTML = `
            <h4>${item.name}</h4>
            <p>Ціна: ${item.price} грн</p>
            <p>Категорія: ${item.category}</p>
          `;
          this.container.appendChild(div);
        }

        // Показати активні фільтри
        const filters = [];
        if (this.searchInput.value) filters.push(`Пошук: "${this.searchInput.value}"`);
        if (this.categoryFilter.value) filters.push(`Категорія: ${this.categoryFilter.value}`);
        this.activeFilters.textContent = filters.length ? `Активні фільтри: ${filters.join(', ')}` : '';
      }
    }

    new FilterSystem(items);
  </script>

</body>
</html>
