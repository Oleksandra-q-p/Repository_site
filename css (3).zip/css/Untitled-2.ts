<script>
  const menuData = {
    "items": [
      {
        "title": "Головна",
        "link": "/",
        "submenu": []
      },
      {
        "title": "Про нас",
        "link": "#",
        "submenu": [
          {
            "title": "Команда",
            "link": "/team",
            "submenu": []
          },
          {
            "title": "Історія",
            "link": "/history",
            "submenu": [
              {
                "title": "2020",
                "link": "/history/2020",
                "submenu": []
              },
              {
                "title": "2021",
                "link": "/history/2021",
                "submenu": []
              }
            ]
          }
        ]
      },
      {
        "title": "Послуги",
        "link": "/services",
        "submenu": []
      },
      {
        "title": "Блог",
        "link": "/blog",
        "submenu": []
      },
      {
        "title": "Контакти",
        "link": "/contact",
        "submenu": []
      }
    ]
  };

  const menuContainer = document.getElementById("menuContainer");

  function createMenuItems(items, level = 1) {
    return items.map(item => {
      const li = document.createElement("li");
      li.classList.add("menu-item");
      li.setAttribute("role", "none");

      const a = document.createElement("a");
      a.textContent = item.title;
      a.href = item.link || "#";
      a.classList.add("menu-link");
      a.setAttribute("role", "menuitem");
      a.tabIndex = 0;

      li.appendChild(a);

      if (item.submenu && item.submenu.length > 0) {
        a.classList.add("has-submenu");

        const subMenu = document.createElement("ul");
        subMenu.classList.add("submenu", `level-${level}`);
        subMenu.setAttribute("role", "menu");

        const subItems = createMenuItems(item.submenu, level + 1);
        subItems.forEach(subLi => subMenu.appendChild(subLi));

        li.appendChild(subMenu);

        a.addEventListener("click", (e) => {
          e.preventDefault();
          subMenu.classList.toggle("open");
          a.classList.toggle("open");
        });
      }

      li.addEventListener("click", () => {
        document.querySelectorAll(".active").forEach(el => el.classList.remove("active"));
        a.classList.add("active");
      });

      return li;
    });
  }

  function renderMenu() {
    const items = createMenuItems(menuData.items);
    items.forEach(item => menuContainer.appendChild(item));
  }

  renderMenu();

  // BURGER BUTTON
  const burger = document.querySelector('.burger-menu');
  burger.addEventListener('click', () => {
    menuContainer.classList.toggle('menu-open');
    burger.setAttribute("aria-expanded", menuContainer.classList.contains("menu-open"));
  });
</script>
